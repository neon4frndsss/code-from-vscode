# Woebot QA Engineer assessment

This repo contains a `app.js` file that when run launches a REST API server that responds to GET and POST HTTP requests. 
Your challenge is to add a unit test file to the project that uses the Mocha test framework to test as much of `app.js` 
logic as you can. When complete, you should be able to run `npm test` to launch the unit tests and display their results.